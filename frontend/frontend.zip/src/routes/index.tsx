import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Sparkles, ArrowRight, Brain, FileText, Eye, Mic, Linkedin,
  Github, Map, Target, Heart, Zap, Check, Star, TrendingUp,
  Rocket, ShieldCheck,
} from "lucide-react";

export const Route = createFileRoute("/")({ component: Landing });

const features = [
  { icon: FileText, title: "AI Resume Builder", desc: "Beautiful templates with AI bullet rewrites, ATS scoring and recruiter-ready formatting." },
  { icon: Sparkles, title: "AI Cover Letter Builder", desc: "Generate tailored letters from any job posting in seconds — with the right tone." },
  { icon: Eye, title: "Recruiter View", desc: "See exactly how recruiters perceive your profile with attention heatmaps and weak-spot detection." },
  { icon: Mic, title: "Interview Simulator", desc: "Behavioral & technical practice with AI follow-ups, scoring and confidence feedback." },
  { icon: Linkedin, title: "LinkedIn Optimizer", desc: "Headline, About and keyword analysis tuned for the recruiters in your niche." },
  { icon: Github, title: "Portfolio Analyzer", desc: "AI reviews your GitHub for depth, architecture, READMEs and tutorial-project red flags." },
  { icon: Map, title: "Career Path Visualizer", desc: "An AI-generated roadmap with skills, projects and roles tailored to your goal." },
  { icon: Target, title: "Application Strength Score", desc: "Real-time score on how strong your application is — before you hit send." },
  { icon: Brain, title: "AI Self-Marketing Coach", desc: "Pitches, branding and recruiter mindset coaching to make you sound like a senior." },
  { icon: Heart, title: "Confidence Mode", desc: "Daily wins, growth tracking and motivation built for the messy job-search journey." },
];

const stats = [
  { v: "92%", l: "users get more interviews in 30 days" },
  { v: "3.4×", l: "more recruiter views on LinkedIn" },
  { v: "18k+", l: "early-career devs launched" },
  { v: "4.9/5", l: "average product rating" },
];

const testimonials = [
  { name: "Maya R.", role: "CS Student → Frontend Intern @ Stripe", text: "Recruiter View was a wake-up call. I rewrote my resume in 2 hours and got 5 callbacks the next week.", initials: "MR" },
  { name: "Tomás A.", role: "Self-taught dev → Junior @ Vercel", text: "The interview simulator felt scarily real. By round 3 I actually believed I belonged in the room.", initials: "TA" },
  { name: "Priya S.", role: "Bootcamp grad → SDE I @ Shopify", text: "Confidence Mode is the only product that ever made job-hunting feel less lonely. Worth every cent.", initials: "PS" },
  { name: "Jules K.", role: "Graduate → Backend Engineer", text: "Launchly told me my GitHub was 'tutorial-shaped'. Brutal. Then it told me exactly how to fix it.", initials: "JK" },
];

const pricing = [
  { name: "Starter", price: "$0", tag: "Free forever", desc: "Get the basics and a taste of the magic.", cta: "Start free", features: ["1 resume", "Basic ATS check", "5 AI rewrites / mo", "Career score"] },
  { name: "Launch", price: "$19", tag: "Most popular", desc: "Everything you need to land your first or next role.", cta: "Start launching", featured: true,
    features: ["Unlimited resumes & cover letters", "Recruiter View + heatmaps", "Interview simulator (unlimited)", "LinkedIn & Portfolio analyzer", "AI Coach + Confidence Mode"] },
  { name: "Pro", price: "$39", tag: "For serious switchers", desc: "Senior-level coaching and deeper insights.", cta: "Go Pro", features: ["Everything in Launch", "Personal career roadmap", "1:1 mock interviews / mo", "Priority AI models", "Advanced analytics"] },
];

function Landing() {
  return (
    <div className="min-h-screen text-foreground">
      <Nav />
      <Hero />
      <LogoStrip />
      <Stats />
      <FeatureGrid />
      <DashboardPreview />
      <RecruiterShowcase />
      <Testimonials />
      <Pricing />
      <CTASection />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50">
      <div className="mx-auto mt-4 max-w-7xl px-4">
        <div className="glass flex items-center justify-between rounded-2xl px-4 py-3 shadow-elegant">
          <Link to="/" className="flex items-center gap-2">
            <LogoMark />
            <span className="text-base font-semibold tracking-tight">Launchly</span>
          </Link>
          <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            <a href="#features" className="hover:text-foreground">Features</a>
            <a href="#recruiter" className="hover:text-foreground">Recruiter View</a>
            <a href="#pricing" className="hover:text-foreground">Pricing</a>
            <a href="#testimonials" className="hover:text-foreground">Stories</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/dashboard" className="hidden rounded-lg px-3 py-2 text-sm text-muted-foreground hover:text-foreground sm:inline">
              Sign in
            </Link>
            <Link to="/dashboard" className="group inline-flex items-center gap-1.5 rounded-lg bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground shadow-elegant transition hover:opacity-95">
              Launch app <ArrowRight className="size-4 transition group-hover:translate-x-0.5" />
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

function LogoMark() {
  return (
    <div className="relative grid size-8 place-items-center rounded-xl bg-gradient-brand glow">
      <Rocket className="size-4 text-primary-foreground" />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-hero" />
      <div className="grid-bg absolute inset-0 opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      <div className="relative mx-auto max-w-7xl px-4 pb-16 pt-20 md:pt-28">
        <div className="mx-auto max-w-3xl text-center">
          <div className="animate-fade-up mx-auto inline-flex items-center gap-2 rounded-full glass px-3.5 py-1.5 text-xs text-muted-foreground">
            <span className="size-1.5 animate-pulse-glow rounded-full bg-[oklch(0.78_0.16_200)]" />
            New — AI Recruiter View 2.0 is live
          </div>
          <h1 className="animate-fade-up [animation-delay:80ms] mt-6 text-balance text-5xl font-semibold tracking-tight md:text-7xl">
            Launch your career with{" "}
            <span className="text-gradient animate-gradient-pan">confidence.</span>
          </h1>
          <p className="animate-fade-up [animation-delay:160ms] mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground">
            Launchly is the AI-powered career growth platform for students, juniors and self-taught devs.
            Build resumes recruiters actually read, simulate real interviews, and grow into the role you want.
          </p>
          <div className="animate-fade-up [animation-delay:240ms] mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link to="/dashboard" className="group inline-flex items-center gap-2 rounded-xl bg-gradient-brand px-6 py-3 text-sm font-semibold text-primary-foreground shadow-elegant glow">
              Start free — no card needed
              <ArrowRight className="size-4 transition group-hover:translate-x-0.5" />
            </Link>
            <a href="#features" className="inline-flex items-center gap-2 rounded-xl glass px-5 py-3 text-sm">
              See how it works
            </a>
          </div>
          <div className="animate-fade-up [animation-delay:320ms] mt-6 flex items-center justify-center gap-6 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><ShieldCheck className="size-3.5" /> Privacy-first</span>
            <span className="inline-flex items-center gap-1.5"><Zap className="size-3.5" /> Setup in 60s</span>
            <span className="inline-flex items-center gap-1.5"><Star className="size-3.5" /> 4.9/5 rating</span>
          </div>
        </div>

        <HeroPreview />
      </div>
    </section>
  );
}

function HeroPreview() {
  return (
    <div className="animate-fade-up [animation-delay:400ms] relative mx-auto mt-16 max-w-6xl">
      <div className="absolute -inset-x-10 -top-10 h-40 bg-gradient-brand opacity-30 blur-3xl" />
      <div className="glass relative overflow-hidden rounded-3xl border p-2 shadow-elegant">
        <div className="rounded-2xl bg-[oklch(0.18_0.025_270)] p-4">
          <div className="mb-3 flex items-center gap-2">
            <span className="size-2.5 rounded-full bg-[oklch(0.7_0.18_25)]" />
            <span className="size-2.5 rounded-full bg-[oklch(0.8_0.16_75)]" />
            <span className="size-2.5 rounded-full bg-[oklch(0.78_0.17_155)]" />
            <div className="ml-3 text-xs text-muted-foreground">launchly.app/dashboard</div>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            <PreviewCard title="Career Score" value="86" delta="+12 this week" tone="violet" />
            <PreviewCard title="Recruiter Impression" value="A−" delta="Stronger than 78%" tone="cyan" />
            <PreviewCard title="Interview Readiness" value="74%" delta="3 mocks completed" tone="pink" />
          </div>
          <div className="mt-3 grid gap-3 md:grid-cols-5">
            <div className="md:col-span-3 rounded-xl glass p-4">
              <div className="mb-3 flex items-center justify-between text-xs text-muted-foreground">
                <span>Profile growth</span><span>Last 30 days</span>
              </div>
              <MiniSparkline />
            </div>
            <div className="md:col-span-2 rounded-xl glass p-4">
              <div className="mb-3 text-xs text-muted-foreground">AI suggestions</div>
              <ul className="space-y-2 text-sm">
                {["Quantify the Stripe internship bullet", "Add 'TypeScript' to LinkedIn About", "Replace tutorial project with API one"].map(s => (
                  <li key={s} className="flex items-start gap-2"><Sparkles className="mt-0.5 size-4 text-[oklch(0.78_0.16_200)]" />{s}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PreviewCard({ title, value, delta, tone }: { title: string; value: string; delta: string; tone: "violet"|"cyan"|"pink" }) {
  const map = { violet: "from-[oklch(0.55_0.20_295)] to-[oklch(0.45_0.16_260)]",
                cyan: "from-[oklch(0.55_0.18_200)] to-[oklch(0.45_0.14_220)]",
                pink: "from-[oklch(0.60_0.20_340)] to-[oklch(0.45_0.16_310)]"};
  return (
    <div className="relative overflow-hidden rounded-xl glass p-4">
      <div className={`absolute -right-6 -top-6 size-24 rounded-full bg-gradient-to-br ${map[tone]} opacity-40 blur-2xl`} />
      <div className="text-xs text-muted-foreground">{title}</div>
      <div className="mt-1 flex items-baseline gap-2">
        <div className="text-3xl font-semibold tracking-tight">{value}</div>
        <div className="text-xs text-[oklch(0.78_0.17_155)]">{delta}</div>
      </div>
    </div>
  );
}

function MiniSparkline() {
  const points = [10,18,16,28,32,30,42,46,52,48,60,72,68,78,86];
  const w = 600, h = 100;
  const max = Math.max(...points), min = Math.min(...points);
  const path = points.map((p,i) => {
    const x = (i/(points.length-1))*w;
    const y = h - ((p-min)/(max-min))*h;
    return `${i===0?"M":"L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(" ");
  const area = `${path} L ${w} ${h} L 0 ${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-24 w-full">
      <defs>
        <linearGradient id="g1" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.72 0.20 295)" stopOpacity="0.5" />
          <stop offset="100%" stopColor="oklch(0.72 0.20 295)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#g1)" />
      <path d={path} stroke="oklch(0.85 0.14 250)" strokeWidth="2" fill="none" />
    </svg>
  );
}

function LogoStrip() {
  const logos = ["Stripe","Vercel","Shopify","Notion","Linear","GitHub","Figma","Datadog"];
  return (
    <section className="border-y border-white/5 py-8">
      <div className="mx-auto max-w-7xl px-4 text-center">
        <p className="mb-5 text-xs uppercase tracking-widest text-muted-foreground">Helping juniors land roles at</p>
        <div className="relative overflow-hidden">
          <div className="flex w-max animate-marquee gap-12 text-lg font-semibold text-muted-foreground/70">
            {[...logos, ...logos].map((l,i) => <span key={i} className="opacity-80">{l}</span>)}
          </div>
        </div>
      </div>
    </section>
  );
}

function Stats() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20">
      <div className="grid gap-4 md:grid-cols-4">
        {stats.map(s => (
          <div key={s.l} className="glass rounded-2xl p-6 shadow-card">
            <div className="text-4xl font-semibold tracking-tight text-gradient">{s.v}</div>
            <div className="mt-2 text-sm text-muted-foreground">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function FeatureGrid() {
  return (
    <section id="features" className="mx-auto max-w-7xl px-4 py-20">
      <SectionHeading
        kicker="Everything you need"
        title="Ten AI superpowers for early-career builders"
        sub="From resume to recruiter reaction — Launchly turns guesswork into a system."
      />
      <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {features.map((f, i) => (
          <div key={f.title} className="group relative overflow-hidden rounded-2xl glass p-6 shadow-card transition hover:-translate-y-0.5 hover:ring-brand">
            <div className="mb-4 inline-grid size-10 place-items-center rounded-xl bg-gradient-brand-soft ring-1 ring-white/10">
              <f.icon className="size-5 text-[oklch(0.85_0.14_250)]" />
            </div>
            <h3 className="text-lg font-semibold">{f.title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
            <div className="mt-5 inline-flex items-center gap-1 text-xs text-muted-foreground transition group-hover:text-foreground">
              Learn more <ArrowRight className="size-3.5" />
            </div>
            <div aria-hidden className="pointer-events-none absolute -right-12 -top-12 size-32 rounded-full bg-gradient-brand opacity-0 blur-3xl transition group-hover:opacity-30" style={{animationDelay: `${i*40}ms`}} />
          </div>
        ))}
      </div>
    </section>
  );
}

function DashboardPreview() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20">
      <SectionHeading
        kicker="Your career, on autopilot"
        title="A dashboard that thinks like a recruiter"
        sub="Career Score, market fit, missing skills and the next best move — all in one place."
      />
      <div className="mt-12 grid gap-6 lg:grid-cols-2">
        <div className="glass rounded-3xl p-6">
          <div className="mb-4 flex items-center justify-between">
            <h4 className="font-semibold">Career Score</h4>
            <span className="rounded-full bg-[oklch(0.78_0.17_155)]/15 px-2 py-0.5 text-xs text-[oklch(0.78_0.17_155)]">+12</span>
          </div>
          <RadialScore value={86} />
          <div className="mt-6 grid grid-cols-3 gap-3 text-center text-xs">
            {[["Resume","92"],["LinkedIn","78"],["Portfolio","81"]].map(([k,v]) => (
              <div key={k} className="rounded-xl bg-white/5 p-3">
                <div className="text-muted-foreground">{k}</div>
                <div className="text-lg font-semibold">{v}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-3xl p-6">
          <h4 className="mb-4 font-semibold">Market fit & growth</h4>
          <MiniSparkline />
          <div className="mt-4 space-y-3">
            {[
              ["Frontend Engineer", 88],
              ["Full-stack Engineer", 74],
              ["Product Engineer", 66],
            ].map(([k, v]) => (
              <div key={k as string}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span>{k as string}</span><span className="text-muted-foreground">{v as number}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/5">
                  <div className="h-full bg-gradient-brand" style={{ width: `${v}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function RadialScore({ value }: { value: number }) {
  const r = 70, c = 2 * Math.PI * r;
  const dash = (value/100)*c;
  return (
    <div className="relative mx-auto grid size-48 place-items-center">
      <svg viewBox="0 0 200 200" className="size-48 -rotate-90">
        <defs>
          <linearGradient id="rg" x1="0" x2="1" y1="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.78 0.16 200)" />
            <stop offset="100%" stopColor="oklch(0.72 0.20 295)" />
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r={r} stroke="oklch(1 0 0 / 0.08)" strokeWidth="14" fill="none" />
        <circle cx="100" cy="100" r={r} stroke="url(#rg)" strokeWidth="14" fill="none"
          strokeLinecap="round" strokeDasharray={`${dash} ${c}`} />
      </svg>
      <div className="absolute text-center">
        <div className="text-4xl font-semibold tracking-tight">{value}</div>
        <div className="text-xs text-muted-foreground">/ 100</div>
      </div>
    </div>
  );
}

function RecruiterShowcase() {
  return (
    <section id="recruiter" className="mx-auto max-w-7xl px-4 py-20">
      <SectionHeading
        kicker="Recruiter View"
        title="See your profile through their eyes"
        sub="Eye-tracking-inspired heatmaps, weak-section detection and an honest score from the AI hiring panel."
      />
      <div className="mt-12 grid gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3 relative overflow-hidden rounded-3xl glass p-6 shadow-card">
          <div className="absolute inset-0 bg-gradient-hero opacity-40" />
          <div className="relative">
            <div className="mb-3 text-xs text-muted-foreground">Attention heatmap (first 7 seconds)</div>
            <div className="relative h-72 overflow-hidden rounded-2xl border border-white/10 bg-[oklch(0.22_0.02_270)] p-4">
              <div className="space-y-2.5">
                <div className="h-3 w-2/3 rounded bg-white/15" />
                <div className="h-2 w-1/3 rounded bg-white/10" />
                <div className="mt-3 h-2 w-full rounded bg-white/10" />
                <div className="h-2 w-5/6 rounded bg-white/10" />
                <div className="h-2 w-4/6 rounded bg-white/10" />
                <div className="mt-4 h-3 w-1/4 rounded bg-white/15" />
                <div className="h-2 w-full rounded bg-white/10" />
                <div className="h-2 w-3/5 rounded bg-white/10" />
                <div className="h-2 w-4/6 rounded bg-white/10" />
              </div>
              {/* Heatmap blobs */}
              <div className="pointer-events-none absolute left-6 top-6 size-40 rounded-full bg-[oklch(0.7_0.22_25)] opacity-50 blur-2xl" />
              <div className="pointer-events-none absolute left-24 top-20 size-28 rounded-full bg-[oklch(0.8_0.18_75)] opacity-40 blur-2xl" />
              <div className="pointer-events-none absolute right-10 bottom-8 size-32 rounded-full bg-[oklch(0.78_0.17_155)] opacity-25 blur-2xl" />
            </div>
          </div>
        </div>
        <div className="lg:col-span-2 space-y-4">
          {[
            { t: "Recruiter Score", v: "82 / 100", c: "Top 22% of juniors" },
            { t: "Readability", v: "Excellent", c: "Avg. 14 words / bullet" },
            { t: "Weak sections", v: "2 detected", c: "Education and About" },
            { t: "Missing impact", v: "5 bullets", c: "AI rewrite available" },
          ].map(x => (
            <div key={x.t} className="glass rounded-2xl p-5">
              <div className="text-xs text-muted-foreground">{x.t}</div>
              <div className="mt-1 flex items-baseline justify-between">
                <div className="text-2xl font-semibold">{x.v}</div>
                <div className="text-xs text-muted-foreground">{x.c}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section id="testimonials" className="mx-auto max-w-7xl px-4 py-20">
      <SectionHeading
        kicker="Loved by early-career devs"
        title="Real wins from real beginners"
        sub="From first-ever interview to first signed offer — these are the stories we live for."
      />
      <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {testimonials.map(t => (
          <figure key={t.name} className="glass flex h-full flex-col rounded-2xl p-6 shadow-card">
            <div className="mb-3 flex gap-0.5 text-[oklch(0.83_0.16_75)]">
              {Array.from({length:5}).map((_,i)=> <Star key={i} className="size-4 fill-current" />)}
            </div>
            <blockquote className="flex-1 text-sm leading-relaxed text-foreground/90">"{t.text}"</blockquote>
            <figcaption className="mt-5 flex items-center gap-3">
              <div className="grid size-9 place-items-center rounded-full bg-gradient-brand text-xs font-semibold text-primary-foreground">{t.initials}</div>
              <div>
                <div className="text-sm font-medium">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.role}</div>
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="mx-auto max-w-7xl px-4 py-20">
      <SectionHeading
        kicker="Simple pricing"
        title="Pay less than one rejected coffee chat"
        sub="Cancel anytime. Free forever plan. No card to start."
      />
      <div className="mt-12 grid gap-5 md:grid-cols-3">
        {pricing.map(p => (
          <div key={p.name} className={`relative rounded-3xl p-6 shadow-card ${p.featured ? "glass-strong ring-1 ring-[oklch(0.72_0.20_295)]/40 glow" : "glass"}`}>
            {p.featured && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-brand px-3 py-1 text-[11px] font-semibold text-primary-foreground">
                {p.tag}
              </div>
            )}
            <div className="text-sm text-muted-foreground">{p.name}</div>
            <div className="mt-2 flex items-baseline gap-1">
              <div className="text-4xl font-semibold tracking-tight">{p.price}</div>
              <div className="text-sm text-muted-foreground">/ mo</div>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
            <Link to="/dashboard" className={`mt-5 inline-flex w-full items-center justify-center rounded-xl px-4 py-2.5 text-sm font-semibold ${p.featured ? "bg-gradient-brand text-primary-foreground glow" : "glass hover:bg-white/10"}`}>
              {p.cta}
            </Link>
            <ul className="mt-6 space-y-2.5 text-sm">
              {p.features.map(f => (
                <li key={f} className="flex items-start gap-2">
                  <Check className="mt-0.5 size-4 text-[oklch(0.78_0.17_155)]" /> {f}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-24 pt-10">
      <div className="relative overflow-hidden rounded-3xl glass-strong p-10 text-center shadow-elegant md:p-16">
        <div className="absolute inset-0 bg-gradient-hero opacity-70" />
        <div className="relative">
          <div className="mx-auto inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 text-xs text-muted-foreground">
            <TrendingUp className="size-3.5" /> Built for the next generation of builders
          </div>
          <h3 className="mx-auto mt-5 max-w-2xl text-balance text-4xl font-semibold tracking-tight md:text-5xl">
            Your future self is <span className="text-gradient">already hired.</span>
          </h3>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Join 18,000+ early-career builders growing into the role they actually want.
          </p>
          <Link to="/dashboard" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-gradient-brand px-6 py-3 text-sm font-semibold text-primary-foreground glow">
            Launch your career <ArrowRight className="size-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/5">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <LogoMark />
            <span className="font-semibold">Launchly</span>
          </div>
          <p className="mt-3 max-w-xs text-sm text-muted-foreground">
            The AI-powered career growth platform for the next generation of builders.
          </p>
        </div>
        {[
          { h: "Product", l: ["Features","Recruiter View","Pricing","Changelog"] },
          { h: "Company", l: ["About","Careers","Press","Contact"] },
          { h: "Resources", l: ["Blog","Guides","Help center","Community"] },
        ].map(c => (
          <div key={c.h}>
            <div className="text-sm font-semibold">{c.h}</div>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              {c.l.map(x => <li key={x}><a href="#" className="hover:text-foreground">{x}</a></li>)}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-5 text-xs text-muted-foreground md:flex-row">
          <div>© {new Date().getFullYear()} Launchly. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-foreground">Privacy</a>
            <a href="#" className="hover:text-foreground">Terms</a>
            <a href="#" className="hover:text-foreground">Security</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SectionHeading({ kicker, title, sub }: { kicker: string; title: string; sub: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <div className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs text-muted-foreground">
        <Sparkles className="size-3.5 text-[oklch(0.85_0.14_250)]" /> {kicker}
      </div>
      <h2 className="mt-4 text-balance text-4xl font-semibold tracking-tight md:text-5xl">{title}</h2>
      <p className="mt-3 text-pretty text-muted-foreground">{sub}</p>
    </div>
  );
}
