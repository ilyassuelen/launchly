import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Card, Progress } from "@/components/launchly/AppShell";
import { Sparkles, Wand2, FileText, Download, Plus, GripVertical, Check, AlertTriangle, Target } from "lucide-react";

export const Route = createFileRoute("/resume")({
  head: () => ({ meta: [{ title: "AI Resume Builder — Launchly" }, { name: "description", content: "Build a recruiter-ready resume with live AI feedback and ATS scoring." }] }),
  component: ResumeBuilder,
});

const sections = ["Header","Summary","Experience","Projects","Education","Skills"];
const templates = [
  { n: "Aurora", c: "from-[oklch(0.72_0.20_295)] to-[oklch(0.55_0.18_200)]" },
  { n: "Mono", c: "from-white/30 to-white/5" },
  { n: "Vercel", c: "from-white/10 to-white/0" },
  { n: "Sunrise", c: "from-[oklch(0.83_0.16_75)] to-[oklch(0.78_0.18_340)]" },
];

function ResumeBuilder() {
  return (
    <AppShell title="Resume Builder" subtitle="Live AI feedback, ATS optimization and recruiter-grade formatting."
      action={<div className="flex gap-2">
        <button className="inline-flex items-center gap-1.5 rounded-xl glass px-3 py-2 text-sm"><Download className="size-4"/> Export PDF</button>
        <button className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground glow"><Wand2 className="size-4"/> Improve all</button>
      </div>}>

      <div className="grid gap-4 lg:grid-cols-12">
        {/* Left: sections */}
        <Card className="lg:col-span-3">
          <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Sections</div>
          <ul className="space-y-1">
            {sections.map((s,i) => (
              <li key={s} className={`group flex items-center justify-between rounded-lg px-2 py-2 text-sm ring-1 ring-transparent hover:bg-white/5 ${i===2?"bg-white/5 ring-white/10":""}`}>
                <span className="flex items-center gap-2"><GripVertical className="size-4 text-muted-foreground"/>{s}</span>
                <span className="text-[10px] text-muted-foreground">drag</span>
              </li>
            ))}
          </ul>
          <button className="mt-3 inline-flex w-full items-center justify-center gap-1 rounded-lg glass px-3 py-2 text-xs hover:bg-white/10"><Plus className="size-3.5"/> Add section</button>

          <div className="mt-6 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Template</div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            {templates.map((t,i) => (
              <button key={t.n} className={`rounded-xl p-1 ring-1 ring-white/10 ${i===0?"ring-[oklch(0.72_0.20_295)]/60":""}`}>
                <div className={`h-20 rounded-lg bg-gradient-to-br ${t.c}`} />
                <div className="mt-1 text-center text-xs">{t.n}</div>
              </button>
            ))}
          </div>
        </Card>

        {/* Center: live preview */}
        <Card className="lg:col-span-6">
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm font-semibold">Live preview</div>
            <span className="text-xs text-muted-foreground">A4 · single page</span>
          </div>
          <div className="rounded-xl bg-white p-8 text-[oklch(0.18_0.02_270)] shadow-elegant">
            <div className="border-b border-black/10 pb-3">
              <div className="text-2xl font-semibold tracking-tight">Maya Reyes</div>
              <div className="text-sm text-black/60">Frontend Engineer · Brooklyn, NY · maya.reyes@launchly.app</div>
            </div>
            <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Summary</h4>
            <p className="mt-1 text-sm">CS senior building consumer-grade React apps. Shipped 4 production tools used by 18k+ users.</p>

            <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Experience</h4>
            <div className="mt-2">
              <div className="flex items-baseline justify-between">
                <div className="font-semibold text-sm">Frontend Intern, Stripe</div>
                <div className="text-xs text-black/60">Summer 2025</div>
              </div>
              <ul className="mt-1 list-disc pl-5 text-sm">
                <li className="bg-[oklch(0.83_0.16_75_/_0.18)] rounded px-1">Built dashboard widget used by <strong>3,400+</strong> merchants weekly.</li>
                <li>Reduced p95 render time by 38% via React Server Components migration.</li>
                <li className="bg-[oklch(0.7_0.22_25_/_0.12)] rounded px-1">Worked on payment flows.</li>
              </ul>
            </div>

            <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Projects</h4>
            <div className="mt-1 text-sm"><strong>Lumen API</strong> · TypeScript, tRPC, Postgres — public API with 1.2k weekly users.</div>

            <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Education</h4>
            <div className="mt-1 text-sm">B.S. Computer Science, NYU · 2026 · GPA 3.8</div>
          </div>
        </Card>

        {/* Right: AI panel */}
        <div className="lg:col-span-3 space-y-4">
          <Card>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
              <Target className="size-4 text-[oklch(0.85_0.14_250)]" /> ATS Score
            </div>
            <div className="text-4xl font-semibold tracking-tight">88<span className="text-base text-muted-foreground">/100</span></div>
            <Progress value={88} color="green" />
            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
              {[["Keywords","92"],["Format","95"],["Impact","78"]].map(([k,v]) => (
                <div key={k} className="rounded-lg bg-white/5 p-2 ring-1 ring-white/10">
                  <div className="text-muted-foreground">{k}</div>
                  <div className="font-semibold">{v}</div>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
              <Sparkles className="size-4 text-[oklch(0.85_0.14_250)]" /> AI suggestions
            </div>
            <ul className="space-y-2 text-sm">
              <li className="flex gap-2"><AlertTriangle className="size-4 mt-0.5 text-[oklch(0.83_0.16_75)]"/> "Worked on payment flows" is weak — quantify impact.</li>
              <li className="flex gap-2"><Sparkles className="size-4 mt-0.5 text-[oklch(0.85_0.14_250)]"/> Add metric to Lumen API project (users, latency, scale).</li>
              <li className="flex gap-2"><Check className="size-4 mt-0.5 text-[oklch(0.78_0.17_155)]"/> Strong action verbs across all bullets.</li>
            </ul>
            <button className="mt-3 inline-flex w-full items-center justify-center gap-1 rounded-lg bg-gradient-brand px-3 py-2 text-xs font-semibold text-primary-foreground glow">
              <Wand2 className="size-3.5"/> Apply all rewrites
            </button>
          </Card>

          <Card>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><FileText className="size-4"/> Keyword fit</div>
            <div className="space-y-2">
              <Progress label="React" value={100} color="green" />
              <Progress label="TypeScript" value={88} />
              <Progress label="Postgres" value={42} color="pink" />
              <Progress label="System Design" value={28} color="pink" />
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
