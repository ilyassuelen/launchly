import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Card, StatCard, Progress } from "@/components/launchly/AppShell";
import { Sparkles, TrendingUp, FileText, Eye, Mic, Linkedin, Github, Target, ArrowRight, Flame, Zap } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, RadialBarChart, RadialBar, PolarAngleAxis } from "recharts";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Launchly" }, { name: "description", content: "Your AI career command center: scores, growth and recommendations." }] }),
  component: Dashboard,
});

const growth = [
  { d: "Mon", v: 42 }, { d: "Tue", v: 48 }, { d: "Wed", v: 56 }, { d: "Thu", v: 61 },
  { d: "Fri", v: 68 }, { d: "Sat", v: 74 }, { d: "Sun", v: 82 },
];

function Dashboard() {
  return (
    <AppShell title="Welcome back, Maya 👋" subtitle="Here's how your career is moving this week."
      action={<button className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground glow"><Zap className="size-4"/> Run AI review</button>}>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Career Score" value="86" delta="+12 this week" icon={TrendingUp} tone="violet" />
        <StatCard label="Recruiter Impression" value="A−" delta="Top 22%" icon={Eye} tone="cyan" />
        <StatCard label="Resume Health" value="92%" delta="Excellent" icon={FileText} tone="green" />
        <StatCard label="Interview Readiness" value="74%" delta="3 mocks done" icon={Mic} tone="pink" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold">Career growth</div>
              <div className="text-xs text-muted-foreground">Last 7 days · all signals combined</div>
            </div>
            <span className="rounded-full bg-[oklch(0.78_0.17_155)]/15 px-2 py-0.5 text-xs text-[oklch(0.78_0.17_155)]">+18%</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer>
              <AreaChart data={growth} margin={{ left: -20, right: 10, top: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="ag" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.72 0.20 295)" stopOpacity="0.6" />
                    <stop offset="100%" stopColor="oklch(0.72 0.20 295)" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
                <XAxis dataKey="d" tick={{ fill: "oklch(0.7 0.03 270)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "oklch(0.7 0.03 270)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "oklch(0.2 0.025 270)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }} />
                <Area dataKey="v" stroke="oklch(0.85 0.14 250)" strokeWidth={2} fill="url(#ag)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <div className="mb-3 text-sm font-semibold">Market Fit Score</div>
          <div className="h-48">
            <ResponsiveContainer>
              <RadialBarChart innerRadius="65%" outerRadius="100%" data={[{name:"fit", value: 78, fill:"oklch(0.72 0.20 295)"}]} startAngle={90} endAngle={-270}>
                <PolarAngleAxis type="number" domain={[0,100]} tick={false} />
                <RadialBar dataKey="value" cornerRadius={20} background={{ fill: "oklch(1 0 0 / 0.06)" }} />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
          <div className="-mt-32 mb-12 text-center">
            <div className="text-3xl font-semibold">78</div>
            <div className="text-xs text-muted-foreground">Frontend Engineer</div>
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card>
          <div className="mb-4 text-sm font-semibold">Profile strength</div>
          <div className="space-y-3">
            <Progress label="Resume" value={92} color="green" />
            <Progress label="LinkedIn" value={78} />
            <Progress label="Portfolio" value={81} color="pink" />
            <Progress label="Interviewing" value={74} />
            <Progress label="Networking" value={56} />
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm font-semibold">Today's AI insights</div>
            <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-xs text-muted-foreground"><Sparkles className="size-3" /> generated 2m ago</span>
          </div>
          <ul className="divide-y divide-white/5">
            {[
              { i: Target, c: "violet", t: "Quantify your Stripe internship bullet — recruiters spend 1.4s here.", a: "Rewrite" },
              { i: Linkedin, c: "cyan", t: "Add 'TypeScript', 'Next.js' and 'Postgres' to your About to match 12 open roles.", a: "Optimize" },
              { i: Github, c: "pink", t: "Replace your tutorial todo-app with the API project — recruiter signal +18%.", a: "Review" },
              { i: Mic, c: "green", t: "Behavioral round 'Tell me about a failure' is your weakest — 3 minute drill?", a: "Practice" },
            ].map((r, i) => (
              <li key={i} className="flex items-center justify-between py-3">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 grid size-8 place-items-center rounded-lg bg-white/5 ring-1 ring-white/10">
                    <r.i className="size-4 text-[oklch(0.85_0.14_250)]" />
                  </div>
                  <div className="text-sm">{r.t}</div>
                </div>
                <button className="inline-flex items-center gap-1 rounded-lg glass px-3 py-1.5 text-xs hover:bg-white/10">
                  {r.a} <ArrowRight className="size-3" />
                </button>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card>
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm font-semibold">Missing skills</div>
            <span className="text-xs text-muted-foreground">vs 32 jobs</span>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            {[["Next.js 15","high"],["tRPC","high"],["Postgres","med"],["AWS S3","med"],["GraphQL","low"],["Playwright","low"]].map(([s,p]) => (
              <span key={s as string} className={`rounded-full px-2.5 py-1 ring-1 ring-white/10 ${p==="high"?"bg-[oklch(0.72_0.20_295)]/20 text-[oklch(0.85_0.14_250)]":p==="med"?"bg-white/5":"bg-white/[0.03] text-muted-foreground"}`}>{s as string}</span>
            ))}
          </div>
          <div className="mt-5 text-sm font-semibold">Suggested learning</div>
          <ul className="mt-2 space-y-2 text-sm text-muted-foreground">
            <li>• Build a Postgres + tRPC mini-app (4h)</li>
            <li>• Ship one Next.js 15 server-action demo</li>
            <li>• Add Playwright to existing portfolio repo</li>
          </ul>
        </Card>

        <Card>
          <div className="mb-3 text-sm font-semibold">Activity heatmap</div>
          <Heatmap />
          <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1"><Flame className="size-3.5 text-[oklch(0.83_0.16_75)]" /> 12-day streak</span>
            <span>Last 13 weeks</span>
          </div>
        </Card>

        <Card>
          <div className="mb-3 text-sm font-semibold">Application pipeline</div>
          <ul className="space-y-3 text-sm">
            {[
              { c: "Stripe", r: "Frontend Intern", s: "Onsite", t: "tomorrow" },
              { c: "Linear", r: "Junior Engineer", s: "Phone screen", t: "Fri" },
              { c: "Vercel", r: "DX Engineer", s: "Applied", t: "Mon" },
              { c: "Shopify", r: "SDE I", s: "Take-home", t: "Wed" },
            ].map(a => (
              <li key={a.c} className="flex items-center justify-between rounded-lg bg-white/5 p-3 ring-1 ring-white/10">
                <div>
                  <div className="text-sm font-medium">{a.c}</div>
                  <div className="text-xs text-muted-foreground">{a.r}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs">{a.s}</div>
                  <div className="text-[11px] text-muted-foreground">{a.t}</div>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </AppShell>
  );
}

function Heatmap() {
  const cells = Array.from({ length: 13 * 7 });
  return (
    <div className="grid grid-flow-col grid-rows-7 gap-1">
      {cells.map((_, i) => {
        const v = ((i * 37) % 5);
        const colors = ["bg-white/5", "bg-[oklch(0.72_0.20_295)]/20", "bg-[oklch(0.72_0.20_295)]/40", "bg-[oklch(0.72_0.20_295)]/70", "bg-[oklch(0.72_0.20_295)]"];
        return <div key={i} className={`size-3 rounded-[3px] ${colors[v]}`} />;
      })}
    </div>
  );
}
