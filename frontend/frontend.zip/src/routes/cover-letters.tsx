import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Card } from "@/components/launchly/AppShell";
import { Sparkles, Wand2, Copy, Download } from "lucide-react";

export const Route = createFileRoute("/cover-letters")({
  head: () => ({ meta: [{ title: "AI Cover Letters — Launchly" }, { name: "description", content: "Generate recruiter-focused cover letters from any job posting." }] }),
  component: CoverLetters,
});

function CoverLetters() {
  return (
    <AppShell title="Cover Letters" subtitle="Tailored, recruiter-focused — generated from any job posting in seconds.">
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <div className="mb-3 text-sm font-semibold">Job posting</div>
          <textarea className="h-44 w-full resize-none rounded-xl bg-white/5 p-3 text-sm outline-none ring-1 ring-white/10 placeholder:text-muted-foreground" defaultValue="Stripe is hiring a Frontend Engineer Intern. You'll work on payment dashboards using React, TypeScript, and design systems. We value pragmatic builders who care about UX and shipping…" />

          <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
            {["Confident","Warm","Concise"].map((t,i) => (
              <button key={t} className={`rounded-lg px-3 py-2 ring-1 ring-white/10 ${i===0?"bg-gradient-brand text-primary-foreground":"glass"}`}>{t}</button>
            ))}
          </div>

          <div className="mt-3 flex gap-2 text-xs">
            <input className="flex-1 rounded-lg bg-white/5 px-3 py-2 ring-1 ring-white/10 placeholder:text-muted-foreground" placeholder="Your name" defaultValue="Maya Reyes" />
            <input className="flex-1 rounded-lg bg-white/5 px-3 py-2 ring-1 ring-white/10 placeholder:text-muted-foreground" placeholder="Role" defaultValue="Frontend Intern" />
          </div>
          <button className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-brand px-4 py-2.5 text-sm font-semibold text-primary-foreground glow">
            <Wand2 className="size-4"/> Generate cover letter
          </button>

          <div className="mt-5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Recent</div>
          <ul className="mt-2 space-y-2 text-sm">
            {["Vercel — DX Engineer","Linear — Junior Engineer","Notion — Product Engineer"].map(x => (
              <li key={x} className="flex items-center justify-between rounded-lg bg-white/5 p-3 ring-1 ring-white/10">
                <span>{x}</span><span className="text-xs text-muted-foreground">2 days ago</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm font-semibold">Live letter</div>
            <div className="flex gap-1">
              <button className="grid size-8 place-items-center rounded-lg glass hover:bg-white/10"><Copy className="size-4"/></button>
              <button className="grid size-8 place-items-center rounded-lg glass hover:bg-white/10"><Download className="size-4"/></button>
            </div>
          </div>
          <div className="rounded-xl bg-white p-8 text-sm leading-relaxed text-[oklch(0.18_0.02_270)] shadow-elegant">
            <p>Dear Stripe Hiring Team,</p>
            <p className="mt-3">When I shipped my first dashboard widget last summer, three thousand merchants used it within a week — and I learned that great frontend isn't just code, it's confidence. That's exactly what drew me to your Frontend Engineer Intern role.</p>
            <p className="mt-3">At NYU and on the side, I've built React apps that prioritize speed and clarity, including <strong>Lumen API</strong>, a TypeScript + tRPC project with 1.2k weekly users. I care deeply about design systems and the small details that make payments feel effortless.</p>
            <p className="mt-3">I'd love to bring that same craftsmanship to Stripe and learn from a team that has set the bar for developer-facing UX.</p>
            <p className="mt-3">Warmly,<br/>Maya Reyes</p>
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-xl bg-white/5 p-3 text-xs ring-1 ring-white/10">
            <Sparkles className="size-4 text-[oklch(0.85_0.14_250)]"/>
            <span className="text-muted-foreground">AI Recruiter rating:</span>
            <span className="font-semibold">9.1 / 10 — strong, specific, and warm.</span>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
