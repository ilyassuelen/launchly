import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Card, Progress } from "@/components/launchly/AppShell";
import { Eye, AlertTriangle, Check, Sparkles } from "lucide-react";

export const Route = createFileRoute("/recruiter-view")({
  head: () => ({ meta: [{ title: "Recruiter View — Launchly" }, { name: "description", content: "See your profile through a recruiter's eyes with attention heatmaps and weak-spot detection." }] }),
  component: RecruiterView,
});

function RecruiterView() {
  return (
    <AppShell title="Recruiter View" subtitle="A 7-second simulated recruiter scan of your profile — with the receipts."
      action={<button className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground glow"><Eye className="size-4"/> Re-run scan</button>}>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-hero opacity-30 pointer-events-none" />
          <div className="relative">
            <div className="mb-3 flex items-center justify-between">
              <div className="text-sm font-semibold">Attention heatmap</div>
              <div className="text-xs text-muted-foreground">First 7s · simulated 8 recruiters</div>
            </div>
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white p-8 text-[oklch(0.18_0.02_270)]">
              <div className="text-xl font-semibold">Maya Reyes</div>
              <div className="text-sm text-black/60">Frontend Engineer · Brooklyn, NY</div>

              <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Summary</h4>
              <p className="mt-1 text-sm">CS senior building consumer-grade React apps. Shipped 4 production tools used by 18k+ users.</p>

              <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Experience</h4>
              <div className="mt-1 text-sm font-semibold">Frontend Intern, Stripe</div>
              <ul className="list-disc pl-5 text-sm">
                <li>Built dashboard widget used by <strong>3,400+</strong> merchants weekly.</li>
                <li>Reduced p95 render time by 38%.</li>
                <li>Worked on payment flows.</li>
              </ul>

              <h4 className="mt-4 text-xs font-semibold uppercase tracking-widest text-black/60">Education</h4>
              <p className="text-sm">B.S. Computer Science, NYU — 2026</p>

              {/* heatmap blobs */}
              <div className="pointer-events-none absolute left-6 top-4 size-44 rounded-full bg-[oklch(0.7_0.22_25)] opacity-40 blur-3xl" />
              <div className="pointer-events-none absolute left-32 top-28 size-32 rounded-full bg-[oklch(0.83_0.16_75)] opacity-35 blur-3xl" />
              <div className="pointer-events-none absolute right-12 top-44 size-36 rounded-full bg-[oklch(0.78_0.17_155)] opacity-25 blur-3xl" />
              <div className="pointer-events-none absolute left-20 bottom-10 size-28 rounded-full bg-[oklch(0.8_0.18_75)] opacity-30 blur-3xl" />
            </div>
            <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1"><span className="size-2.5 rounded-full bg-[oklch(0.7_0.22_25)]"/> Hot zones</span>
              <span className="inline-flex items-center gap-1"><span className="size-2.5 rounded-full bg-[oklch(0.83_0.16_75)]"/> Warm</span>
              <span className="inline-flex items-center gap-1"><span className="size-2.5 rounded-full bg-[oklch(0.78_0.17_155)]"/> Cool</span>
            </div>
          </div>
        </Card>

        <div className="lg:col-span-4 space-y-4">
          <Card>
            <div className="text-xs text-muted-foreground">Recruiter Score</div>
            <div className="mt-1 flex items-baseline gap-2">
              <div className="text-4xl font-semibold tracking-tight text-gradient">82</div>
              <div className="text-sm text-muted-foreground">/ 100 · Top 22%</div>
            </div>
            <Progress value={82} />
          </Card>
          <Card>
            <div className="mb-3 text-sm font-semibold">Signals</div>
            <div className="space-y-3">
              <Progress label="Readability" value={91} color="green" />
              <Progress label="Impact density" value={62} />
              <Progress label="Technical depth" value={74} />
              <Progress label="Visual hierarchy" value={88} color="green" />
            </div>
          </Card>
          <Card>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><Sparkles className="size-4 text-[oklch(0.85_0.14_250)]"/> AI panel feedback</div>
            <ul className="space-y-2 text-sm">
              <li className="flex gap-2"><Check className="mt-0.5 size-4 text-[oklch(0.78_0.17_155)]"/> Strong opening line — instant credibility.</li>
              <li className="flex gap-2"><AlertTriangle className="mt-0.5 size-4 text-[oklch(0.83_0.16_75)]"/> Education sits in a cool zone — consider moving up.</li>
              <li className="flex gap-2"><AlertTriangle className="mt-0.5 size-4 text-[oklch(0.7_0.22_25)]"/> 1 vague bullet kills momentum after 4s.</li>
            </ul>
          </Card>
        </div>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-3">
        {[
          { t: "Strengths", c: "green", items: ["Clear hierarchy", "Strong action verbs", "Quantified bullets", "Modern formatting"] },
          { t: "Weak spots", c: "warning", items: ["Vague payment-flows bullet", "No portfolio link visible", "Long Education block"] },
          { t: "Missing impact", c: "pink", items: ["Project: add user count", "Internship: add metric", "Skills: add 'TypeScript'"] },
        ].map(b => (
          <Card key={b.t}>
            <div className="mb-3 text-sm font-semibold">{b.t}</div>
            <ul className="space-y-2 text-sm">
              {b.items.map(i => (
                <li key={i} className="flex gap-2">
                  <span className={`mt-1.5 size-1.5 rounded-full ${b.c==="green"?"bg-[oklch(0.78_0.17_155)]":b.c==="warning"?"bg-[oklch(0.83_0.16_75)]":"bg-[oklch(0.78_0.18_340)]"}`}/>
                  {i}
                </li>
              ))}
            </ul>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}
