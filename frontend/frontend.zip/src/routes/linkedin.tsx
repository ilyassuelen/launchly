import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Card, Progress } from "@/components/launchly/AppShell";
import { Linkedin, Sparkles, Wand2, Plus } from "lucide-react";

export const Route = createFileRoute("/linkedin")({
  head: () => ({ meta: [{ title: "LinkedIn Analyzer — Launchly" }, { name: "description", content: "Optimize your LinkedIn headline, About and keywords for recruiters in your niche." }] }),
  component: LinkedInPage,
});

function LinkedInPage() {
  return (
    <AppShell title="LinkedIn Analyzer" subtitle="Headline, About and keyword strategy tuned for the recruiters in your niche."
      action={<button className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground glow"><Wand2 className="size-4"/> Optimize all</button>}>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <div className="text-xs text-muted-foreground">Profile strength</div>
          <div className="mt-1 text-4xl font-semibold tracking-tight text-gradient">78</div>
          <Progress value={78} />
          <div className="mt-3 text-xs text-muted-foreground">Stronger than 64% of juniors in your role.</div>
        </Card>
        <Card>
          <div className="mb-3 text-sm font-semibold">Recruiter signals</div>
          <div className="space-y-3">
            <Progress label="Headline" value={62} color="pink" />
            <Progress label="About" value={70} />
            <Progress label="Skills" value={88} color="green" />
            <Progress label="Activity" value={45} color="pink" />
          </div>
        </Card>
        <Card>
          <div className="mb-3 text-sm font-semibold">Missing keywords</div>
          <div className="flex flex-wrap gap-2 text-xs">
            {["TypeScript","Next.js","Postgres","tRPC","Server Components","Playwright"].map(k => (
              <span key={k} className="inline-flex items-center gap-1 rounded-full bg-[oklch(0.72_0.20_295)]/15 px-2.5 py-1 text-[oklch(0.85_0.14_250)] ring-1 ring-white/10">
                <Plus className="size-3"/> {k}
              </span>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><Linkedin className="size-4 text-[oklch(0.78_0.16_200)]"/> Headline</div>
          <div className="rounded-xl bg-white/5 p-3 text-sm ring-1 ring-white/10">CS student at NYU · React enthusiast</div>
          <div className="mt-2 flex items-start gap-2 text-sm">
            <Sparkles className="mt-1 size-4 text-[oklch(0.85_0.14_250)]"/>
            <div>
              <div className="font-semibold">AI rewrite</div>
              <div className="rounded-xl bg-gradient-brand-soft p-3 ring-1 ring-white/10">Frontend Engineer · React, TypeScript, Next.js · Shipping consumer-grade apps used by 18k+ users · Open to junior roles</div>
            </div>
          </div>
        </Card>
        <Card>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><Linkedin className="size-4 text-[oklch(0.78_0.16_200)]"/> About</div>
          <textarea className="h-44 w-full resize-none rounded-xl bg-white/5 p-3 text-sm outline-none ring-1 ring-white/10" defaultValue="I'm a senior at NYU studying CS. I love building things on the web and have interned at Stripe…" />
          <button className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-gradient-brand px-3 py-2 text-xs font-semibold text-primary-foreground glow"><Wand2 className="size-3.5"/> Improve with AI</button>
        </Card>
      </div>

      <div className="mt-4">
        <Card>
          <div className="mb-3 text-sm font-semibold">Networking suggestions</div>
          <div className="grid gap-3 md:grid-cols-3">
            {[
              { n: "Sara Liu", r: "Senior Eng @ Stripe", c: "Worked on payment dashboards" },
              { n: "Daniel Park", r: "Recruiter @ Vercel", c: "Hires juniors quarterly" },
              { n: "Anya Petrova", r: "EM @ Linear", c: "Posts about junior hiring" },
            ].map(p => (
              <div key={p.n} className="rounded-xl bg-white/5 p-4 ring-1 ring-white/10">
                <div className="flex items-center gap-3">
                  <div className="grid size-10 place-items-center rounded-full bg-gradient-brand text-xs font-semibold text-primary-foreground">{p.n.split(" ").map(x=>x[0]).join("")}</div>
                  <div>
                    <div className="text-sm font-semibold">{p.n}</div>
                    <div className="text-xs text-muted-foreground">{p.r}</div>
                  </div>
                </div>
                <div className="mt-3 text-xs text-muted-foreground">{p.c}</div>
                <button className="mt-3 inline-flex w-full items-center justify-center rounded-lg bg-gradient-brand px-3 py-1.5 text-xs font-semibold text-primary-foreground">Draft message</button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
