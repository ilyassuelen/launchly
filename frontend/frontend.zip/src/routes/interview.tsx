import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Card, Progress } from "@/components/launchly/AppShell";
import { Mic, Send, Sparkles, Code2, MessageSquare, Volume2, Play } from "lucide-react";

export const Route = createFileRoute("/interview")({
  head: () => ({ meta: [{ title: "Interview Simulator — Launchly" }, { name: "description", content: "Practice behavioral and technical interviews with AI follow-ups and scoring." }] }),
  component: Interview,
});

function Interview() {
  return (
    <AppShell title="Interview Simulator" subtitle="Real questions. AI follow-ups. Honest feedback that builds confidence."
      action={<button className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground glow"><Play className="size-4"/> Start mock</button>}>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-3">
          <div className="mb-3 text-sm font-semibold">Mode</div>
          <div className="space-y-2">
            {[{i:MessageSquare,t:"Behavioral"},{i:Code2,t:"Technical"},{i:Sparkles,t:"System Design"}].map((m,i) => (
              <button key={m.t} className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm ring-1 ring-white/10 ${i===0?"bg-gradient-brand-soft":"glass hover:bg-white/10"}`}>
                <m.i className="size-4"/> {m.t}
              </button>
            ))}
          </div>
          <div className="mt-5 text-sm font-semibold">Role</div>
          <select className="mt-2 w-full rounded-lg bg-white/5 px-3 py-2 text-sm ring-1 ring-white/10">
            <option>Frontend Engineer</option>
            <option>Full-stack Engineer</option>
            <option>Product Engineer</option>
          </select>
          <div className="mt-5 text-sm font-semibold">Difficulty</div>
          <div className="mt-2 flex gap-1">
            {["Junior","Mid","Senior"].map((d,i)=>(
              <button key={d} className={`flex-1 rounded-lg px-2 py-1.5 text-xs ring-1 ring-white/10 ${i===0?"bg-gradient-brand text-primary-foreground":"glass"}`}>{d}</button>
            ))}
          </div>

          <div className="mt-6 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Past sessions</div>
          <ul className="mt-2 space-y-2 text-sm">
            {[["Behavioral · 8 Qs","82"],["Technical · 6 Qs","74"],["System · 4 Qs","68"]].map(([n,s]) => (
              <li key={n as string} className="flex items-center justify-between rounded-lg bg-white/5 p-2 ring-1 ring-white/10">
                <span>{n as string}</span>
                <span className="text-xs text-[oklch(0.78_0.17_155)]">{s as string}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="lg:col-span-6">
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm font-semibold">Live session</div>
            <span className="inline-flex items-center gap-1 rounded-full bg-[oklch(0.78_0.17_155)]/15 px-2 py-0.5 text-xs text-[oklch(0.78_0.17_155)]">
              <span className="size-1.5 rounded-full bg-[oklch(0.78_0.17_155)] animate-pulse-glow"/> Recording
            </span>
          </div>

          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-brand text-xs font-semibold text-primary-foreground">AI</div>
              <div className="rounded-2xl rounded-tl-sm bg-white/5 p-3 text-sm ring-1 ring-white/10">
                Tell me about a time you disagreed with a teammate. What happened, and what would you do differently?
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <div className="rounded-2xl rounded-tr-sm bg-gradient-brand-soft p-3 text-sm ring-1 ring-white/10 max-w-md">
                During my Stripe internship, I disagreed on using Redux for a small dashboard. I proposed Zustand and we A/B tested both…
              </div>
              <div className="grid size-9 shrink-0 place-items-center rounded-full bg-white/10 text-xs font-semibold">M</div>
            </div>
            <div className="flex gap-3">
              <div className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-brand text-xs font-semibold text-primary-foreground">AI</div>
              <div className="rounded-2xl rounded-tl-sm bg-white/5 p-3 text-sm ring-1 ring-white/10">
                Nice — what was the actual impact, and how did you bring your teammate along after the data came back?
              </div>
            </div>
          </div>

          <div className="mt-5 flex items-center gap-2 rounded-2xl glass p-2">
            <button className="grid size-10 place-items-center rounded-xl bg-gradient-brand text-primary-foreground glow">
              <Mic className="size-4"/>
            </button>
            <input className="flex-1 bg-transparent px-2 text-sm outline-none placeholder:text-muted-foreground" placeholder="Type your answer or hold to record…" />
            <button className="grid size-10 place-items-center rounded-xl glass hover:bg-white/10"><Volume2 className="size-4"/></button>
            <button className="grid size-10 place-items-center rounded-xl glass hover:bg-white/10"><Send className="size-4"/></button>
          </div>
        </Card>

        <div className="lg:col-span-3 space-y-4">
          <Card>
            <div className="mb-2 text-sm font-semibold">Live feedback</div>
            <div className="space-y-3">
              <Progress label="Confidence" value={78} />
              <Progress label="Communication" value={84} color="green" />
              <Progress label="Structure (STAR)" value={62} color="pink" />
              <Progress label="Specificity" value={71} />
            </div>
          </Card>
          <Card>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><Sparkles className="size-4 text-[oklch(0.85_0.14_250)]"/> AI tips</div>
            <ul className="space-y-2 text-sm">
              <li>• Lead with the outcome, then the situation.</li>
              <li>• Add a number — "shipped to 3.4k merchants".</li>
              <li>• Slow down 8% — pacing read as nervous.</li>
            </ul>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
